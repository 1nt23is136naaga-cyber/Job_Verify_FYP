// content.js — ScamShield
// Extracts job/email text from the active page and returns it to the popup.

// Helper to expand LinkedIn 'see more' buttons
function expandSeeMore() {
  const buttons = document.querySelectorAll('button.inline-show-more-text__button, button.see-more, button.feed-shared-inline-show-more-text__see-more-less-toggle');
  buttons.forEach(b => {
    if (b.innerText.toLowerCase().includes('more') || b.innerText.toLowerCase().includes('see')) {
      try { b.click(); } catch(e){}
    }
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extract_text') {
    let extractedText = '';
    const host = window.location.hostname;

    if (host.includes('linkedin.com')) {
      // 1. Expand hidden text
      expandSeeMore();
      
      // 2. Selectors ranked by specificity (Job pages -> Feed posts -> General)
      const selectors = [
        '#job-details',
        '.jobs-description__container',
        '.jobs-description',
        '.job-view-layout',
        '.feed-shared-update-v2__description-wrapper',
        '.update-components-text',
        '.feed-shared-text',
        '.attributed-text-segment-list__content',
        'article',
        'main'
      ];
      
      // 3. Find the longest chunk of text among all matches
      let bestMatch = '';
      for (const sel of selectors) {
        const elements = document.querySelectorAll(sel);
        for (const el of elements) {
          const txt = el.innerText.trim();
          if (txt.length > bestMatch.length && txt.length > 50) {
            bestMatch = txt;
          }
        }
        // If we found a block longer than a typical tweet, it's likely our target
        if (bestMatch.length > 250) break;
      }
      
      extractedText = bestMatch;
      
      // 4. Last resort
      if (!extractedText) {
        const main = document.querySelector('main');
        extractedText = main ? main.innerText : document.body.innerText;
      }

    } else if (host.includes('mail.google.com')) {
      // Gmail specific logic stays the same
      const emailBodyElements = document.querySelectorAll('.a3s.aiL');
      if (emailBodyElements.length > 0) {
        extractedText = emailBodyElements[emailBodyElements.length - 1].innerText;
      } else {
        const msgBody = document.querySelector('[data-message-id] .ii.gt');
        extractedText = msgBody ? msgBody.innerText : document.body.innerText;
      }

    } else {
      // Generic fallback
      const main = document.querySelector('main');
      extractedText = main ? main.innerText : document.body.innerText;
    }

    sendResponse({ text: extractedText });
  }
  return true; 
});
